---- MODULE metal_reports_proofs ----
EXTENDS Naturals, TLAPS

CONSTANTS Users, MaxQty, MaxTotalQty, MaxPrice, Metals, WorkflowStates

Pairs == Users \X Metals

EmptyReport == [qty |-> 0, price |-> 0, status |-> "DRAFT"]

VARIABLES reports

vars == <<reports>>

HasReport(u, m) == reports[<<u, m>>] # EmptyReport

Init == reports = [p \in Pairs |-> EmptyReport]

CreateDraft(u, m, q, p) ==
    /\ <<u, m>> \in Pairs
    /\ q \in 1..MaxQty
    /\ p \in 0..MaxPrice
    /\ reports[<<u, m>>] = EmptyReport
    /\ reports' = [reports EXCEPT ![<<u, m>>] = [qty |-> q, price |-> p, status |-> "DRAFT"]]

AmendDraft(u, m, q, p) ==
    /\ <<u, m>> \in Pairs
    /\ q \in 1..MaxQty
    /\ p \in 0..MaxPrice
    /\ reports[<<u, m>>] # EmptyReport
    /\ reports[<<u, m>>].status = "DRAFT"
    /\ LET old == reports[<<u, m>>]
           newQty == old.qty + q
       IN /\ newQty <= MaxTotalQty
          /\ reports' = [reports EXCEPT ![<<u, m>>] = [qty |-> newQty, price |-> p, status |-> "DRAFT"]]

SubmitReport(u, m) ==
    /\ <<u, m>> \in Pairs
    /\ reports[<<u, m>>] # EmptyReport
    /\ reports[<<u, m>>].status = "DRAFT"
    /\ LET old == reports[<<u, m>>]
       IN reports' = [reports EXCEPT ![<<u, m>>] = [qty |-> old.qty, price |-> old.price, status |-> "SUBMITTED"]]

ApproveReport(u, m) ==
    /\ <<u, m>> \in Pairs
    /\ reports[<<u, m>>] # EmptyReport
    /\ reports[<<u, m>>].status = "SUBMITTED"
    /\ LET old == reports[<<u, m>>]
       IN reports' = [reports EXCEPT ![<<u, m>>] = [qty |-> old.qty, price |-> old.price, status |-> "APPROVED"]]

RejectReport(u, m) ==
    /\ <<u, m>> \in Pairs
    /\ reports[<<u, m>>] # EmptyReport
    /\ reports[<<u, m>>].status = "SUBMITTED"
    /\ LET old == reports[<<u, m>>]
       IN reports' = [reports EXCEPT ![<<u, m>>] = [qty |-> old.qty, price |-> old.price, status |-> "REJECTED"]]

Next ==
    \/ \E u \in Users, m \in Metals, q \in 1..MaxQty, p \in 0..MaxPrice:
        CreateDraft(u, m, q, p)
    \/ \E u \in Users, m \in Metals, q \in 1..MaxQty, p \in 0..MaxPrice:
        AmendDraft(u, m, q, p)
    \/ \E u \in Users, m \in Metals:
        SubmitReport(u, m)
    \/ \E u \in Users, m \in Metals:
        ApproveReport(u, m)
    \/ \E u \in Users, m \in Metals:
        RejectReport(u, m)
    \/ UNCHANGED vars

Spec == Init /\ [][Next]_vars

\* ================================================================
\* Invariants
\* ================================================================

LocalStatusTypeOK ==
    \A u \in Users, m \in Metals :
        reports[<<u, m>>].status \in {"DRAFT", "SUBMITTED", "APPROVED", "REJECTED"}

QtyPositive ==
    \A u \in Users, m \in Metals :
        HasReport(u, m) => reports[<<u, m>>].qty >= 1

\* ================================================================
\* Proof: LocalStatusTypeOK is inductive
\* ================================================================

THEOREM TypeInvariantLocal == Spec => []LocalStatusTypeOK
    <1>1. Init => LocalStatusTypeOK
        BY DEF Init, LocalStatusTypeOK, EmptyReport, Pairs
    <1>2. LocalStatusTypeOK /\ [Next]_vars => LocalStatusTypeOK'
        <2>1. SUFFICES ASSUME LocalStatusTypeOK, [Next]_vars
              PROVE LocalStatusTypeOK'
            OBVIOUS
        <2>2. CASE \E u \in Users, m \in Metals, q \in 1..MaxQty, p \in 0..MaxPrice :
                  CreateDraft(u, m, q, p)
            BY <2>1, <2>2, SMT DEF LocalStatusTypeOK, CreateDraft, EmptyReport, Pairs
        <2>3. CASE \E u \in Users, m \in Metals, q \in 1..MaxQty, p \in 0..MaxPrice :
                  AmendDraft(u, m, q, p)
            BY <2>1, <2>3, SMT DEF LocalStatusTypeOK, AmendDraft, EmptyReport, Pairs
        <2>4. CASE \E u \in Users, m \in Metals : SubmitReport(u, m)
            BY <2>1, <2>4, SMT DEF LocalStatusTypeOK, SubmitReport, EmptyReport, Pairs
        <2>5. CASE \E u \in Users, m \in Metals : ApproveReport(u, m)
            BY <2>1, <2>5, SMT DEF LocalStatusTypeOK, ApproveReport, EmptyReport, Pairs
        <2>6. CASE \E u \in Users, m \in Metals : RejectReport(u, m)
            BY <2>1, <2>6, SMT DEF LocalStatusTypeOK, RejectReport, EmptyReport, Pairs
        <2>7. CASE UNCHANGED vars
            BY <2>1, <2>7, SMT DEF LocalStatusTypeOK, vars
        <2>q. QED BY <2>1, <2>2, <2>3, <2>4, <2>5, <2>6, <2>7
                  DEF Next
    <1>q. QED BY <1>1, <1>2, PTL DEF Spec

\* ================================================================
\* Proof: QtyPositive is invariant
\* ================================================================

THEOREM SafetyLocal == Spec => []QtyPositive
    <1>1. Init => QtyPositive
        BY DEF Init, QtyPositive, HasReport, EmptyReport, Pairs
    <1>2. QtyPositive /\ LocalStatusTypeOK /\ [Next]_vars => QtyPositive'
        <2>1. SUFFICES ASSUME QtyPositive, LocalStatusTypeOK, [Next]_vars
              PROVE QtyPositive'
            OBVIOUS
        <2>2. CASE \E u \in Users, m \in Metals, q \in 1..MaxQty, p \in 0..MaxPrice :
                  CreateDraft(u, m, q, p)
            BY <2>1, <2>2, SMT DEF QtyPositive, HasReport, CreateDraft, EmptyReport, Pairs
        <2>3. CASE \E u \in Users, m \in Metals, q \in 1..MaxQty, p \in 0..MaxPrice :
                  AmendDraft(u, m, q, p)
            BY <2>1, <2>3, SMT DEF QtyPositive, HasReport, AmendDraft, EmptyReport, Pairs, LocalStatusTypeOK
        <2>4. CASE \E u \in Users, m \in Metals : SubmitReport(u, m)
            BY <2>1, <2>4, SMT DEF QtyPositive, HasReport, SubmitReport, EmptyReport, Pairs
        <2>5. CASE \E u \in Users, m \in Metals : ApproveReport(u, m)
            BY <2>1, <2>5, SMT DEF QtyPositive, HasReport, ApproveReport, EmptyReport, Pairs
        <2>6. CASE \E u \in Users, m \in Metals : RejectReport(u, m)
            BY <2>1, <2>6, SMT DEF QtyPositive, HasReport, RejectReport, EmptyReport, Pairs
        <2>7. CASE UNCHANGED vars
            BY <2>1, <2>7, SMT DEF QtyPositive, HasReport, vars
        <2>q. QED BY <2>1, <2>2, <2>3, <2>4, <2>5, <2>6, <2>7
                  DEF Next
    <1>q. QED BY <1>1, <1>2, TypeInvariantLocal, PTL DEF Spec

====
